//
//  FoodiesService.swift
//  Foodies
//
//  Created by Tommy Yon Prakoso on 20/11/22.
//

import Foundation
import RxSwift

protocol FoodiesServiceProtocol {
    func fetchFoodies() -> Observable<[Foodies]>
}

class FoodiesService: FoodiesServiceProtocol {
    
    func fetchFoodies() -> Observable<[Foodies]> {
        
        return Observable.create { observer -> Disposable in
            
             
            guard let path = Bundle.main.path(forResource: "foodies", ofType: "json") else {
                observer.onError(NSError(domain: "", code: -1 ))
                return Disposables.create {
                }
            }
            do {
                let data = try Data(contentsOf: URL(fileURLWithPath: path), options: .mappedIfSafe)
                let foodies = try JSONDecoder().decode([Foodies].self, from: data)
                
                observer.onNext(foodies)
                    
            } catch {
                    observer.onError(error)
                     
                }
            
            return Disposables.create {}
                
            }
        }
    }

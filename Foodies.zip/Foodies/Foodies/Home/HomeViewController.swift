//
//  ViewController.swift
//  Foodies
//
//  Created by Tommy Yon Prakoso on 20/11/22.
//

import UIKit
import SnapKit

class HomeViewController: UIViewController {
    
    private lazy var nextBtn = UIButton()

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .red
        
        view.addSubview(nextBtn)
        nextBtn.backgroundColor = .blue
        nextBtn.addTarget(self, action: #selector(didTapNext), for: .touchUpInside)
        nextBtn.snp.makeConstraints { make in
            make.centerY.centerX.equalTo(view)
            make.width.equalTo(200)
        }
    }
    
    
    
    
       @objc private func didTapNext() {
          let vc = ListFoodViewController()
           navigationController?.pushViewController(vc, animated: true)
       }

}



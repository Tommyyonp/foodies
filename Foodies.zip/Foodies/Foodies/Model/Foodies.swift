//
//  Foodies.swift
//  Foodies
//
//  Created by Tommy Yon Prakoso on 20/11/22.
//

import Foundation

struct Foodies: Decodable {
    let name: String
    let location : Location
}

enum Location : String, Decodable  {
    case Korea
    case Indonesia
    case Italia
    case Japan
    case France
}

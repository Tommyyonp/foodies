//
//  ListFoodViewController.swift
//  Foodies
//
//  Created by Tommy Yon Prakoso on 20/11/22.
//

import UIKit
import RxSwift
import SnapKit
import RxCocoa

class ListFoodViewController: UIViewController {
    
    let service = FoodiesService()
    let bag = DisposeBag()
    private var vm: ListFoodViewModel!
    
    private lazy var tableView = UITableView()

    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        bindVM()
    }
    
    func setupUI() {
        view.addSubview(tableView)
        tableView.backgroundColor = .blue
        tableView.snp.makeConstraints { make in
            make.edges.equalTo(view.safeAreaLayoutGuide)
        }
        tableView.register(UITableViewCell.self, forCellReuseIdentifier: "cell")
    }
    
    func bindVM() {
        vm.fetchFoodiesViewModels().bind(to: tableView.rx.items(cellIdentifier: "cell")) { index, vm, cell in
            cell.textLabel?.text = vm.displayText
        }.disposed(by: bag)
    }
}

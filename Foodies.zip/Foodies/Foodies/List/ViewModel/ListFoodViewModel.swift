//
//  ListFoodViewModel.swift
//  Foodies
//
//  Created by Tommy Yon Prakoso on 20/11/22.
//

import Foundation
import RxSwift

final class ListFoodViewModel {
    let title = "Foodies"
    
    private let foodiesService: FoodiesServiceProtocol
    
    init(foodiesService: FoodiesServiceProtocol = FoodiesService()) {
        self.foodiesService = foodiesService
    }
    
    func fetchFoodiesViewModels() -> Observable<[FoodiesViewModel]> {
        foodiesService.fetchFoodies().map { $0.map { FoodiesViewModel( foodies: $0)} }
    }
}

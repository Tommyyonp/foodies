//
//  FoodiesViewModel.swift
//  Foodies
//
//  Created by Tommy Yon Prakoso on 20/11/22.
//

import Foundation

class FoodiesViewModel {
    
    private let foodies : Foodies
    
    var displayText: String{
        return foodies.name + " - " + foodies.location.rawValue
    }
    
    init(foodies: Foodies){
        self.foodies = foodies
    }
}
